public class DatabaseHelper {
    package com.example.smartparking;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

    public class DatabaseHelper extends SQLiteOpenHelper {

        private static final String DATABASE_NAME = "ParkingDB";
        private static final String TABLE_NAME = "ParkingSpots";
        private static final String COL_ID = "ID";
        private static final String COL_SPOT = "SpotNumber";
        private static final String COL_LOCATION = "Location";
        private static final String COL_AVAILABILITY = "IsAvailable";

        public DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, SpotNumber TEXT, Location TEXT, IsAvailable INTEGER)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }

        public boolean insertSpot(String spotNumber, String location) {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(COL_SPOT, spotNumber);
            contentValues.put(COL_LOCATION, location);
            contentValues.put(COL_AVAILABILITY, 1); // 1 = Available
            long result = db.insert(TABLE_NAME, null, contentValues);
            return result != -1;
        }

        public Cursor getAvailableSpots() {
            SQLiteDatabase db = this.getReadableDatabase();
            return db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COL_AVAILABILITY + "=1", null);
        }

        public boolean reserveSpot(int id) {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(COL_AVAILABILITY, 0); // 0 = Not Available
            int result = db.update(TABLE_NAME, contentValues, "ID=?", new String[]{String.valueOf(id)});
            return result > 0;
        }

        public Cursor getAllSpots() {
            SQLiteDatabase db = this.getReadableDatabase();
            return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        }

        public boolean deleteSpot(int id) {
            SQLiteDatabase db = this.getWritableDatabase();
            return db.delete(TABLE_NAME, "ID=?", new String[]{String.valueOf(id)}) > 0;
        }
    }

}
