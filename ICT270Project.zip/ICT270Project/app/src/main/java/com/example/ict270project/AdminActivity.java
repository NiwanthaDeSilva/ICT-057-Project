package com.example.ict270project;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AdminActivity extends AppCompatActivity {
    DatabaseHelper dbHelper;
    ListView listView;
    EditText spotInput, locationInput;
    Button addSpotButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        dbHelper = new DatabaseHelper(this);
        listView = findViewById(R.id.listView);
        spotInput = findViewById(R.id.spotInput);
        locationInput = findViewById(R.id.locationInput);
        addSpotButton = findViewById(R.id.addSpotButton);

        addSpotButton.setOnClickListener(v -> {
            String spot = spotInput.getText().toString();
            String location = locationInput.getText().toString();
            boolean result = dbHelper.insertSpot(spot, location);
            if (result) {
                Toast.makeText(this, "Spot added!", Toast.LENGTH_SHORT).show();
                loadAllSpots();
            } else {
                Toast.makeText(this, "Error adding spot.", Toast.LENGTH_SHORT).show();
            }
        });

        loadAllSpots();
    }

    private void loadAllSpots() {
        Cursor cursor = dbHelper.getAllSpots();
        String[] from = {"SpotNumber", "Location"};
        int[] to = {R.id.spotNumber, R.id.location};

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.spot_item, cursor, from, to, 0);
        listView.setAdapter(adapter);

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            boolean result = dbHelper.deleteSpot((int) id);
            if (result) {
                Toast.makeText(this, "Spot deleted!", Toast.LENGTH_SHORT).show();
                loadAllSpots();
            } else {
                Toast.makeText(this, "Error deleting spot.", Toast.LENGTH_SHORT).show();
            }
            return true;
        });
    }
}