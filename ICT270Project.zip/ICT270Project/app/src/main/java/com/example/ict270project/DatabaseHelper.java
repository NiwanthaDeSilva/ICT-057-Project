package com.example.smartparking;




import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Information
    private static final String DATABASE_NAME = "SmartParking.db";
    private static final int DATABASE_VERSION = 1;

    // Table Name
    private static final String TABLE_NAME = "ParkingSpots";

    // Table Columns
    private static final String COL_ID = "ID";
    private static final String COL_SPOT_NUMBER = "SpotNumber";
    private static final String COL_LOCATION = "Location";
    private static final String COL_IS_AVAILABLE = "IsAvailable";

    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Create Table
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_SPOT_NUMBER + " TEXT, " +
                COL_LOCATION + " TEXT, " +
                COL_IS_AVAILABLE + " INTEGER)";
        db.execSQL(createTable);
    }

    // Upgrade Table
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Insert Parking Spot
    public boolean insertParkingSpot(String spotNumber, String location) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_SPOT_NUMBER, spotNumber);
        contentValues.put(COL_LOCATION, location);
        contentValues.put(COL_IS_AVAILABLE, 1); // 1 = Available
        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;
    }

    // Fetch All Parking Spots
    public Cursor getAllParkingSpots() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }

    // Fetch Only Available Parking Spots
    public Cursor getAvailableParkingSpots() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COL_IS_AVAILABLE + "=1", null);
    }

    // Reserve a Parking Spot (Set IsAvailable = 0)
    public boolean reserveParkingSpot(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_IS_AVAILABLE, 0); // 0 = Reserved
        int result = db.update(TABLE_NAME, contentValues, COL_ID + "=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    // Delete a Parking Spot
    public boolean deleteParkingSpot(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_NAME, COL_ID + "=?", new String[]{String.valueOf(id)});
        return result > 0;
    }
}
