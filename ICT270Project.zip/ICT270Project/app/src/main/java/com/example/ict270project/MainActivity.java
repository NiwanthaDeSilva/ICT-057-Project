package com.example.ict270project;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    com.example.smartparking.DatabaseHelper dbHelper;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbHelper = new com.example.smartparking.DatabaseHelper(this);
        listView = findViewById(R.id.listView);

        loadAvailableSpots();
    }

    private void loadAvailableSpots() {
        Cursor cursor = dbHelper.getAvailableSpots();
        String[] from = {"SpotNumber", "Location"};
        int[] to = {R.id.spotNumber, R.id.location};

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.spot_item, cursor, from, to, 0);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            boolean result = dbHelper.reserveSpot((int) id);
            if (result) {
                Toast.makeText(this, "Spot reserved!", Toast.LENGTH_SHORT).show();
                loadAvailableSpots();
            } else {
                Toast.makeText(this, "Error reserving spot.", Toast.LENGTH_SHORT).show();

            });
        }
    }
}



